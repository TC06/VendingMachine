/**
 */
package dk.dtu.compute.mbse.yawl;

import org.pnml.tools.epnk.pnmlcoremodel.PetriNetType;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>YAWL Net</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dk.dtu.compute.mbse.yawl.YawlPackage#getYAWLNet()
 * @model
 * @generated
 */
public interface YAWLNet extends PetriNetType {
} // YAWLNet
